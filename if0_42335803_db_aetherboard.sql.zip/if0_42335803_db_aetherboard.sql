-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql107.infinityfree.com
-- Generation Time: Jul 24, 2026 at 09:40 PM
-- Server version: 11.4.12-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_42335803_db_aetherboard`
--

-- --------------------------------------------------------

--
-- Table structure for table `folders`
--

CREATE TABLE `folders` (
  `id_folder` int(11) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `folder_name` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `folders`
--

INSERT INTO `folders` (`id_folder`, `id_user`, `folder_name`, `created_at`) VALUES
(1, 1, 'randomm', '2026-07-22 17:17:47'),
(2, 2, 'alam', '2026-07-24 07:21:11'),
(3, 2, 'Random ', '2026-07-24 07:41:04'),
(4, 1, 'Alam', '2026-07-24 10:04:24'),
(5, 2, 'cafe', '2026-07-24 16:02:20'),
(6, 1, 'coffe', '2026-07-24 16:32:54');

-- --------------------------------------------------------

--
-- Table structure for table `moodboards`
--

CREATE TABLE `moodboards` (
  `id_board` int(11) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `id_folder` int(11) DEFAULT NULL,
  `url_original` text DEFAULT NULL,
  `url_display` text DEFAULT NULL,
  `photographer` varchar(100) DEFAULT NULL,
  `photographer_url` text DEFAULT NULL,
  `saved_at` timestamp NULL DEFAULT current_timestamp(),
  `alt` varchar(255) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `moodboards`
--

INSERT INTO `moodboards` (`id_board`, `id_user`, `id_folder`, `url_original`, `url_display`, `photographer`, `photographer_url`, `saved_at`, `alt`) VALUES
(1, 1, 1, 'https://images.pexels.com/photos/12968388/pexels-photo-12968388.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940', 'https://images.pexels.com/photos/12968388/pexels-photo-12968388.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940', 'Miguel Cuenca', 'https://www.pexels.com/@miguel-cuenca-67882473', '2026-07-22 17:18:10', ''),
(2, 2, 2, 'https://images.pexels.com/photos/5223569/pexels-photo-5223569.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940', 'https://images.pexels.com/photos/5223569/pexels-photo-5223569.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940', 'Ozan Kerem Karakaya', 'https://www.pexels.com/@oznkary', '2026-07-24 07:21:27', ''),
(3, 2, 2, 'https://images.pexels.com/photos/17552919/pexels-photo-17552919.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940', 'https://images.pexels.com/photos/17552919/pexels-photo-17552919.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940', 'Mahmud KARA', 'https://www.pexels.com/@mahmud-kara-629789268', '2026-07-24 07:21:41', ''),
(4, 2, 3, 'https://images.pexels.com/photos/6905177/pexels-photo-6905177.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940', 'https://images.pexels.com/photos/6905177/pexels-photo-6905177.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940', 'Pew Nguyen', 'https://www.pexels.com/@nguyendesigner', '2026-07-24 07:41:23', ''),
(6, 1, 4, 'https://images.pexels.com/photos/28759219/pexels-photo-28759219.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940', 'https://images.pexels.com/photos/28759219/pexels-photo-28759219.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940', 'Juliano H. da Silva', 'https://www.pexels.com/@juliano-h-da-silva-1921876490', '2026-07-24 10:04:26', ''),
(7, 1, 4, 'https://images.pexels.com/photos/1105389/pexels-photo-1105389.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940', 'https://images.pexels.com/photos/1105389/pexels-photo-1105389.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940', 'Johannes Plenio', 'https://www.pexels.com/@jplenio', '2026-07-24 10:05:09', ''),
(8, 1, 4, 'https://images.pexels.com/photos/6129776/pexels-photo-6129776.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940', 'https://images.pexels.com/photos/6129776/pexels-photo-6129776.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940', 'Quang Nguyen Vinh', 'https://www.pexels.com/@quang-nguyen-vinh-222549', '2026-07-24 10:05:43', ''),
(9, 1, 1, 'https://images.pexels.com/photos/17279851/pexels-photo-17279851.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940', 'https://images.pexels.com/photos/17279851/pexels-photo-17279851.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940', 'Egor Komarov', 'https://www.pexels.com/@egorkomarov', '2026-07-24 12:20:33', ''),
(10, 1, 1, 'https://images.pexels.com/photos/14529813/pexels-photo-14529813.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940', 'https://images.pexels.com/photos/14529813/pexels-photo-14529813.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940', 'thecactusena â€Ž', 'https://www.pexels.com/@thecactusena', '2026-07-24 15:39:51', 'A minimalist indoor setting featuring a wooden table with a small potted plant against a light wall.'),
(13, 1, 1, 'https://images.pexels.com/photos/37048220/pexels-photo-37048220.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940', 'https://images.pexels.com/photos/37048220/pexels-photo-37048220.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940', 'Bibin Jaimon', 'https://www.pexels.com/@bibinjaimon', '2026-07-24 15:45:46', 'A stylish cafe interior with wooden chairs and natural lighting in Payyanur, India.'),
(14, 2, 5, 'https://images.pexels.com/photos/15105621/pexels-photo-15105621.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940', 'https://images.pexels.com/photos/15105621/pexels-photo-15105621.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940', 'Namzy', 'https://www.pexels.com/@namzy-419907319', '2026-07-24 16:02:27', 'Warm ambiance in a modern cafÃ© with stylish neon peace sign lighting.'),
(15, 2, 5, 'https://images.pexels.com/photos/5863648/pexels-photo-5863648.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940', 'https://images.pexels.com/photos/5863648/pexels-photo-5863648.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940', 'Rachel Claire', 'https://www.pexels.com/@rachel-claire', '2026-07-24 16:07:46', 'A low angle shot showcasing industrial style pendant lights against a dark ceiling, creating a moody atmosphere.'),
(16, 1, 4, 'https://images.pexels.com/photos/33541852/pexels-photo-33541852.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940', 'https://images.pexels.com/photos/33541852/pexels-photo-33541852.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940', 'Rahul Parihar', 'https://www.pexels.com/@rahul-parihar-54878034', '2026-07-24 16:21:26', 'A breathtaking view of the Rocky Mountains with pine trees in Banff, Alberta, Canada.'),
(17, 1, 6, 'https://images.pexels.com/photos/16358790/pexels-photo-16358790.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940', 'https://images.pexels.com/photos/16358790/pexels-photo-16358790.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940', 'Eliza Ari', 'https://www.pexels.com/@ellusionist', '2026-07-24 16:42:43', 'Warm interior view of Pera Bakery in Istanbul reveals people enjoying an intimate evening.');

-- --------------------------------------------------------

--
-- Table structure for table `search_history`
--

CREATE TABLE `search_history` (
  `id_search` int(11) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `keyword` varchar(100) DEFAULT NULL,
  `searched_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `search_history`
--

INSERT INTO `search_history` (`id_search`, `id_user`, `keyword`, `searched_at`) VALUES
(6, 1, 'langit', '2026-07-24 17:30:48'),
(7, 1, 'coffe', '2026-07-24 17:31:18'),
(8, 1, 'laut', '2026-07-24 17:31:33'),
(9, 1, 'padang rumput', '2026-07-24 17:31:52');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fullname` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullname`, `email`, `password`, `created_at`) VALUES
(1, 'Auliyaa', 'auliya67@gmail.com', '$2y$10$mCSVIqlLVa4quUYLjPRRteAtDaz/LBJol0J2yoTORz/qTTkpYzcie', '2026-07-22 17:00:30'),
(2, 'Johanna', 'johanna@gmail.com', '$2y$10$Pz3HHIEgoAKXK/FKKrU6WOhdTC3Pt0GoP1j.St9qOEmkdUd6NZWtS', '2026-07-24 07:15:57'),
(3, 'bangke', 'bangke@gmail.con', '$2y$10$bCFKBfxwPzp5td6W6S6Zt.lR6yQsai02IddUwN8kjKo6Tck9uLWu6', '2026-07-24 07:23:41'),
(4, 'Majorie De Luca', 'majories@gmail.com', '$2y$10$x7dRPxhjO4IrXYu2x7pOy.Njd8d7ygVvhlPdNGiRFBOjLFnVZXJ22', '2026-07-24 07:40:20'),
(6, 'caca', 'fifilaiya@gmail.com', '$2y$10$b9mBEB9.eaiGzQFCeyCr5u95HW2oEiJN86e.6/erm1R0a3beiRudS', '2026-07-24 11:06:44');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `folders`
--
ALTER TABLE `folders`
  ADD PRIMARY KEY (`id_folder`);

--
-- Indexes for table `moodboards`
--
ALTER TABLE `moodboards`
  ADD PRIMARY KEY (`id_board`);

--
-- Indexes for table `search_history`
--
ALTER TABLE `search_history`
  ADD PRIMARY KEY (`id_search`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `folders`
--
ALTER TABLE `folders`
  MODIFY `id_folder` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `moodboards`
--
ALTER TABLE `moodboards`
  MODIFY `id_board` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `search_history`
--
ALTER TABLE `search_history`
  MODIFY `id_search` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
